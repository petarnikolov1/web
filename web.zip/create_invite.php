<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = htmlspecialchars($_POST['date']);
    $hour = htmlspecialchars($_POST['hour']);
    $presenter = htmlspecialchars($_POST['presenter']);
    $faculty_number = htmlspecialchars($_POST['faculty_number']);
    
    // Simple invite template
    $invite = "
    <html>
    <head>
        <title>Presentation Invite</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                text-align: center;
                padding: 50px;
            }
            .invite {
                border: 2px solid #ccc;
                padding: 20px;
                border-radius: 10px;
                display: inline-block;
                max-width: 600px;
                margin: auto;
            }
            .invite h2 {
                color: #5cb85c;
            }
            .invite p {
                font-size: 18px;
            }
        </style>
    </head>
    <body>
        <div class='invite'>
            <h2>Presentation Invite</h2>
            <p><strong>Date:</strong> $date</p>
            <p><strong>Hour:</strong> $hour</p>
            <p><strong>Presenter:</strong> $presenter</p>
            <p><strong>Faculty Number:</strong> $faculty_number</p>
        </div>
    </body>
    </html>
    ";

    // Display the invite
    echo $invite;
}
?>
