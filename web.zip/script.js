// This file is optional for simple form submission but can be used for additional client-side functionality
document.getElementById('inviteForm').addEventListener('submit', function(event) {
    // Additional client-side validation can be added here
});
