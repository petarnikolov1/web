# web
Файловата система на проекта "Генератор на покани" от курса по WEB технологии,
изготвен от Александър Киряков и Петър Николов изглежда по следния начин:

web
├───data
│   └───images
│   │ ... 
│   
├───javascript
│   | ...
│
├───php
│   ├───PHPMailer
│   └───vendor
│       ├───composer
│       └───phpmailer
│       │ ... (php файлове) 
│ 
└───styles
│   │ ...
│ 
│ - create_invite.html
│ - index.html
│ - login.html
│ - README.md
│ - register.html